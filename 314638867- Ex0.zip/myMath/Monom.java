
package myMath;
/**
 * This class represents a simple "Monom" of shape a*x^b, where a is a real number and a is an integer (summed a none negative), 
 * see: https://en.wikipedia.org/wiki/Monomial 
 * The class implements function and support simple operations as: construction, value at x, derivative, add and multiply. 
 * @author Boaz
 *
 */
public class Monom implements function{

/**
	*construction that bulid's Monom 
	 * 
	 * @param a
	 * @param b
	 */
	public Monom(double a, int b){
		if(b <0)
			throw new RuntimeException("Eror , mistake power");
		this.set_coefficient(a);
		this.set_power(b);
	}

	/**
	 * construction that bulid's Monom that equls to other Monom(ot.Monom)
	 * @param ot
	 */
	public Monom(Monom ot) {
		if(ot._power <0)
			throw new RuntimeException("Eror , mistake power");
		this._coefficient = ot._coefficient;
		this._power = ot._power;
	}
	// ***************** add your code below **********************
	/**
	 *construction that bulid's empty Monom 
	 */
	public Monom() {
		set_power(0);
		set_coefficient(0);
	}
	/**
	 * Init_from_string is function that we use to help Monom class reading a Monom from the expression "a*x^b"  , thatthis function enter the "a" to _coefficient and the "b" to _power 
	 * 
	 * @param s
	 * @return
	 */
	private static Monom init_from_string(String s) {
		if(s==null)			
			throw new RuntimeException("Eror, There is no Monom");
		double a=0;
		int b=0;
		String in = s.toLowerCase();
		int ind_x = in.indexOf("x");
		if(ind_x < 0) {
			a = Double.parseDouble(in);
		}
		else {
			String c = in.substring(0, ind_x);
			a = Double.parseDouble(c);
			int ind_p = in.indexOf("^");
			if(ind_p < 0) {
				String p =  in.substring(ind_x + 1);
				p = "1" + p;
				b = Integer.parseInt(p);
				if(b != 1) {
					throw new RuntimeException("Eror , mistake power");
				}
			}
			else {
				b = Integer.parseInt(in.substring(ind_p+1));
			}
		}
		return new Monom(a , b);
	}
/**
*construction that bulid's Monom 
	 * @param S
	 */
	public Monom(String S) {
		Monom _new = init_from_string(S);
		this._coefficient = _new._coefficient;
		this._power = _new._power;
	}
/**
 * this function adding a Monom to our Monom in this class , it well work only if two Monom's have the same power 
	 *  
	 * @param arr
	 */
	public void add(Monom arr) {
		if(this._power != arr._power) {
			throw new RuntimeException("Eror, Not the same Power");
		}
		else {
			set_coefficient(this._coefficient + arr._coefficient);
		}
	}
/**
	*this function substract from our Monom(in this class) other Monom that we enter , it well work only if two Monom's have the same power 
	 * 
	 * @param arr
	 */
	public void substract(Monom arr) {
		if(this._power != arr._power) {
			throw new RuntimeException("Eror, Not the same Power");
		}
		else {
			set_coefficient(this._coefficient - arr._coefficient);
		}
	}
/**
	*this functoin we use to know what our coefficient of the Monom(because _coefficient is Private we can't call them out of this class) 
	 * 
	 * @return
	 */
	
	public double get_coefficient() {
		return _coefficient;
	}
/**
	*this functoin we use to know what our power of the Monom(because _Power is Private we can't call them out of this class) 
	 * 
	 * @return
	 */
	public int get_power() {
		return _power;
	}
/**
	*this function multiply  our Monom(in this class) to other Monom that we enter , it well work all the time didn't matter if two Monoms haven't the same power 
	 * 
	 * @param arr
	 */
	public void multiply(Monom arr) {
		set_coefficient(this._coefficient * arr._coefficient);			
		set_power(this._power + arr._power);	
	}
	/**
	 * this functoin help us to derivative our Monom 
	 */
	public void derivative() {
		set_coefficient((this._coefficient) *( this._power));
		set_power((this._power) - 1);
	}
	/**
	 *this functoin we use to Print our Monom in this class 
	 **/
	public String toString() {
		if(this._power == 1)
			return ""+this._coefficient + "X";
		else if(this._power == 0)
			return ""+this._coefficient ;
		else if(this._coefficient==0)
			return "0";
		return ""+this._coefficient + "X^" + this.get_power();
	}


	//****************** Private Methods and Data *****************
/**
	* we use this function to change or seting our _coefficient 
	*/
	private void set_coefficient(double a){
		this._coefficient = a;
	}
/**
	* we use this functoin to change  or seting our _power 
	 * 
	 * @param p
	 */
	private void set_power(int p) {
		this._power = p;
	}

	private double _coefficient; // 
	private int _power;
/**
	*this function we use to know what the value of y in the function in any x value 
	 * 
	 */
	@Override
	public double f(double x) {
		// TODO Auto-generated method stub
		return _coefficient * Math.pow(x , _power);
	} 
}
