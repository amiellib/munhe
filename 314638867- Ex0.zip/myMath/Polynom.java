package myMath;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.function.Predicate;

import myMath.Monom;
/**
 * This class represents a Polynom with add, multiply functionality, it also should support the following:
 * 1. Riemann's Integral: https://en.wikipedia.org/wiki/Riemann_integral
 * 2. Finding a numerical value between two values (currently support root only f(x)=0).
 * 3. Derivative
 * 
 * @author Boaz
 *
 */
public class Polynom implements Polynom_able{

	private ArrayList<Monom> arr ;
	private Monom_Comperator _compare = new Monom_Comperator();

	// ********** add your code below ***********
/**
	*construction that bulid's empty Polynom 
	 * 
	 */
	public Polynom() {
		arr = new ArrayList<Monom>() ;
	}
/**
	*construction that bulid's Polynom from String(the String sholud be Polynom or Monom) 
	 * 
	 * @param s
	 */
	public Polynom(String s) {
		arr = new ArrayList<Monom>() ;
		Polynom p = init_from_string(s);
		Iterator<Monom> m = p.iteretor();
		while(m.hasNext()) {
			this.add(m.next());
		}
	}
/**
 * construction that bulid's polynom from String
 * @param s
 * @return
 */
	private static Polynom init_from_string(String s) {
		if(s==null) {throw new RuntimeException("Wrong parameter for the Monom Constractor - should not be NULL!!!");}
		String[] p = s.split(" ");
		Polynom ans = new Polynom();
		for(int i=0;i<p.length;i++) {
			String t = p[i];
			if(!t.contains("+") || t.length()>1) {
				Monom c = new Monom(t);
				ans.add(c);
			}
		}
		return ans ;
	}
/**
	*this function we use to know what the value of y in the function(Polynom) in any x value 
	 * 
	 */
	@Override
	public double f(double x) {
		double ans = 0;
		Iterator<Monom> m = this.iteretor();
		while(m.hasNext()) {
			ans += m.next().f(x);
		}

		return ans;
	}
/**
	*this function adding Polynom to our Polynom 
	 * 
	 */
	@Override
	public void add(Polynom_able p1) {
		// TODO Auto-generated method stub
		Iterator<Monom> n = p1.iteretor();
		while(n.hasNext()) {
			Monom s = n.next();
			add(s);
		}
	}
/**
	*this function adding Monom to our polynom 
	 * 
	 */
	@Override
	public void add(Monom m1) {
		Iterator<Monom> n = this.iteretor();
		boolean _stop = false;
		while(n.hasNext() && _stop==false) {
			Monom s = n.next();
			if(s.get_power() == m1.get_power()) {
				s.add(m1);
				_stop = true ;
				if(s.get_coefficient() == 0)
					n.remove();
			}
		}
		if(_stop == false) {
			arr.add(m1);
			arr.sort(_compare);
		}

	}
/**
	*this function substract Polynom from our Polynom 
	 * 
	 */
	@Override
	public void substract(Polynom_able p1) {
		Iterator<Monom> n = p1.iteretor();
		while(n.hasNext()) {
			Monom s = n.next();
			substract(s);	
		}
	}
/**
	this function substract Monom from our polynom .
	 * 
	 * @param m1
	 */
	public void substract(Monom m1) {
		Iterator<Monom> n = this.iteretor();
		boolean _stop = false;
		while(n.hasNext() && _stop==false) {
			Monom s = n.next();
			if(s.get_power() == m1.get_power()) {
				s.substract(m1);
				_stop = true ;
				if(s.get_coefficient() == 0)
					n.remove();
			}
		}
		if(_stop == false) {
			Monom m2 = new Monom(m1.get_coefficient()*-1 , m1.get_power());
			arr.add(m2);
			arr.sort(_compare);
		}
	}
/**
	this function Multiply Polynom with our Polynom 
	 * 
	 */
	@Override
	public void multiply(Polynom_able p1) {
		// TODO Auto-generated method stub
		Iterator<Monom> v1 = this.iteretor();
		Polynom ans = new Polynom();
		while(v1.hasNext()) {
			Monom m1=v1.next();
			Iterator<Monom> v2 = p1.iteretor();
			while(v2.hasNext()) {
				Monom m2=v2.next();
				Monom m3 = new Monom(m2);
				m3.multiply(m1);
				ans.add(m3);
			}
		}
		this.arr = ans.arr;
	}
/**
	*this function checking if our Polynom equals to other Polynom that we enter 
	 * 
	 */
	@Override
	public boolean equals(Polynom_able p1) {
		arr.sort(_compare);
		((Polynom)p1).arr.sort(_compare);
		if(arr.size() != ((Polynom)p1).arr.size())
			return false;

		Iterator<Monom>n1 = this.iteretor();
		Iterator<Monom>n2 = p1.iteretor();
		while(n1.hasNext()){
			Monom s1 = n1.next();
			Monom s2 = n2.next();
			if(s1.get_coefficient() != s2.get_coefficient() || s1.get_power() != s2.get_power())
				return false;
		}

		return true;
	}
/**
	this function checking if the Polynom is null or not 
	 * 
	 */
	@Override
	public boolean isZero() {
		if(arr.size() != 0)
			return false;
		return true;
	}
/**
	*this functoin Calculates the root with our Polynom 
	 * 
	 */
	@Override
	public double root(double x0, double x1, double eps) {
		double y0 = this.f(x0);
		double y1 = this.f(x1);

		if(y0*y1>0) {
			throw new RuntimeException("Error: f(x0) and f(x1) should be on oposite sides of the X asix");
		}

		double delta_x = Math.abs(x0-x1);
		double delta_y = Math.abs(y0-y1);
		if (delta_x>eps || delta_y>eps) {
			double x_mid = (x0+x1)/2;
			double y_mid = this.f(x_mid);
			double dir = y0*y_mid;
			if(dir<0) {
				return root(x0,x_mid, eps);
			}
			else {
				return root(x_mid, x1, eps);
			}
		}
		return x0;	}
/**
	*this function copying and saving the Polynom 
	 * 
	 */
	@Override
	public Polynom_able copy() {
		Polynom p = new Polynom();
		Iterator<Monom> s = this.iteretor();
		while( s.hasNext()) {
			Monom m = s.next();
			p.arr.add(new Monom(m));
		}
		return p;
	}
/**
	*this functoin we use to derivative our Polynom in this class 
	 * 
	 */
	@Override
	public Polynom_able derivative() {
		Polynom p = new Polynom();
		Iterator<Monom> n = this.iteretor();
		while(n.hasNext()) {
			Monom m1 = n.next();
			Monom m2 = new Monom(m1);
			m2.derivative();
			p.add(m2);
		}
		return p;
	}
/**
	*this functoin Calculates the area in our Polynom from  x0 to x1 
	 * 
	 */
	@Override
	public double area(double x0, double x1, double eps) {
		double delta = ( x1 - x0 ) / eps ;
		double ans = 0;
		for (int i = 0; i < delta ; i++) {
			ans += delta*f(x0 + i*delta);
		}

		return ans;
	}
/**
 * this functoin help us Moving in the Polynom from Monom to other Monom .
 */
		@Override
	public Iterator<Monom> iteretor() {
		// TODO Auto-generated method stub
		return this.arr.iterator();
	}
/**
	*this functoin we use to Print our Polynom 
	 * 
	 */
	public String toString() {
		String ans = "";
		Iterator<Monom> m1 = arr.iterator();
		while(m1.hasNext()) {
			Monom m2 = m1.next();
			ans += m2.toString();
		}
		return ans;
	}



}
