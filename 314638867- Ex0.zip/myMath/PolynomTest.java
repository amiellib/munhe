package myMath;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PolynomTest {

	@Test
	void testPolynom() {
		Polynom p = new Polynom();
		if(!p.isZero())
			fail("Eror , Empty Polynom");
	}


	@Test
	void testPolynomString() {
		Polynom p1=new Polynom("3x^8 + 5x^3 + 2x^4 + 1x");
		Polynom p=new Polynom();
		p.add(new Monom(3,8));
		p.add(new Monom(5,3));
		p.add(new Monom(2,4));
		p.add(new Monom(1,1));
		if(!p.equals(p1))
			fail("Eror , uncorrect constractor");
	}



	@Test
	void testF() {
		double a = Math.random()*1000 ;
		int _pow = (int)Math.random()*1000 ;
		Monom m1 = new Monom(a , _pow);
		int _x = (int)Math.random()*1000 ;
		Polynom p = new Polynom();
		p.add(m1);
		if(p.f(_x) != (a * Math.pow(_x,_pow)))
			fail("Eror , value of Y is uncorrect");
	}

	@Test
	void testAddPolynom_able() {
		double a1 = Math.random()*1000 ;
		int _pow1 = (int)Math.random()*1000 ;
		Monom m1 = new Monom(a1 , _pow1);
		double a2 = Math.random()*1000 ;
		int _pow2 = (int)Math.random()*1000 ;
		Monom m2 = new Monom(a2 , _pow2);
		double a3 = Math.random()*1000 ;
		int _pow3 = (int)Math.random()*1000 ;
		Monom m3 = new Monom(a3 , _pow3);
		Polynom p1 = new Polynom();
		p1.add(m1);
		p1.add(m2);
		p1.add(m3);
		Polynom p2 = new Polynom();
		p2.add(m1);
		p2.add(m2);
		if(!p1.equals(p2))
			fail("Not yet implemented");
	}

	@Test
	void testAddMonom() {
		Polynom p1=new Polynom();
		p1.add(new Monom(2,2));
		p1.add(new Monom(2,1));
		p1.add(new Monom(2,0));
		Monom p2=new Monom(2,2);
		p1.add(p2);
		Polynom p3=new Polynom();
		p3.add(new Monom(4,2));
		p3.add(new Monom(2,1));
		p3.add(new Monom(2,0));
		if(!p3.equals(p1))
			fail("Eror , fail adding Monom");
	}

	@Test
	void testSubstractPolynom_able() {
		double a1 = Math.random()*1000 ;
		int _pow1 = (int)Math.random()*1000 ;
		Monom m1 = new Monom(a1 , _pow1);
		double a2 = Math.random()*1000 ;
		int _pow2 = (int)Math.random()*1000 ;
		Monom m2 = new Monom(a2 , _pow2);
		double a3 = Math.random()*1000 ;
		int _pow3 = (int)Math.random()*1000 ;
		Monom m3 = new Monom(a3 , _pow3);
		Polynom p1 = new Polynom();
		p1.add(m1);
		p1.add(m2);
		p1.add(m3);
		Polynom p2 = new Polynom();
		p2.add(m1);
		p2.add(m2);
		Polynom p3 = new Polynom();
		p3.add(m3);
		p1.substract(p3);
		if(!p1.equals(p2))
			fail("Eror , fail Substract Polynom");
	}

	@Test
	void testSubstractMonom() {
		double a1 = Math.random()*1000 ;
		int _pow1 = (int)Math.random()*1000 ;
		Monom m1 = new Monom(a1 , _pow1);
		double a2 = Math.random()*1000 ;
		int _pow2 = (int)Math.random()*1000 ;
		Monom m2 = new Monom(a2 , _pow2);
		double a3 = Math.random()*1000 ;
		int _pow3 = (int)Math.random()*1000 ;
		Monom m3 = new Monom(a3 , _pow3);
		Polynom p1 = new Polynom();
		p1.add(m1);
		p1.add(m2);
		p1.add(m3);
		Polynom p2 = new Polynom();
		p2.add(m1);
		p2.add(m2);
		p1.substract(m3);
		if(!p1.equals(p2))
			fail("Eror , fail Substract Monom");
	}

	@Test
	void testMultiply() {
		Polynom p=new Polynom();
		p.add(new Monom(2,2));
		p.add(new Monom(2,1));
		p.add(new Monom(2,0));
		Polynom p1=new Polynom();
		p1.add(new Monom(2,2));
		p1.add(new Monom(2,1));
		p.multiply(p1);
		Polynom s=new Polynom();
		s.add(new Monom(4,4));
		s.add(new Monom(8,3));
		s.add(new Monom(8,2));
		s.add(new Monom(4,1));
		if(!s.equals(p))
			fail("Eror , wrong Multiply");
	}

	@Test
	void testEqualsPolynom_able() {
		Polynom p1=new Polynom();
		p1.add(new Monom(2,2));
		p1.add(new Monom(2,1));
		Polynom p2=new Polynom();
		p2.add(new Monom(2,2));
		p2.add(new Monom(2,1));
		if(!p1.equals(p2))
			fail("Eror , equal function not working");
	}

	@Test
	void testIsZero() {
		Polynom p = new Polynom() ;
		if(!p.isZero())
			fail("Eror , checking if Polynom empty eror");
	}

	@Test
	void testRoot() {
		Polynom p1=new Polynom();
		p1.add(new Monom(-100,0));
		p1.add(new Monom(1,3));
		double e=0.01;
		double root=p1.root(0, 100, e);
		if(Math.abs(p1.f(root))>=e)
			fail("Eror , uncorrect Root");
	}


	@Test
	void testDerivative() {
		Polynom p=new Polynom();
		p.add(new Monom(2,2));
		p.add(new Monom(2,1));
		Polynom p1=new Polynom();
		p1.add(new Monom(4,1));
		p1.add(new Monom(2,0));
		if(!p.derivative().equals(p1))
			fail("Eror , uncorrect Derivative");
	}

	@Test
	void testArea() {/**
		Polynom p1=new Polynom();
		p1.add(new Monom(2,2));
		p1.add(new Monom(5,1));
		p1.add(new Monom(10,0));
		double x=p1.area(-5, 5, 0.08);
		System.out.println(x);
		x=p1.area(-5, 5, 0.09);
		System.out.println(x);
		Polynom p=new Polynom();
		p.add(new Monom(9,4));
		p.add(new Monom(4,2));
		p.add(new Monom(7,1));
		p.add(new Monom(5,0));
		x=p.area(-2, 0, 0.04);
		System.out.println(x);
		System.out.println();
		fail("Not yet implemented");
	 **/
	}


}
